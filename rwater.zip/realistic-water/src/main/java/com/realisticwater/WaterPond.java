package com.realisticwater;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;

/**
 * Kolam air hasil tuangan: permukaan bergelombang (persamaan gelombang 2D di grid kecil).
 * Tiap tetes yang mendarat membuat riak; riak menyebar, memantul, dan meredam.
 * Digambar sebagai mesh transparan; sorot putih muncul di lereng gelombang (kilau).
 * Kolam mengecil dan menguap kalau tidak ada tetes baru.
 */
public class WaterPond {

	private static final Identifier WHITE = Identifier.of("minecraft", "textures/misc/white.png");
	private static final ArrayList<WaterPond> PONDS = new ArrayList<>();
	private static final int MAX_PONDS = 6;

	private static final int N = 24;
	private static final float HALF = 0.8f;
	private static final float CELL = 2 * HALF / N;

	private final ClientWorld world;
	private final double cx, cy, cz;
	private final float[] h = new float[N * N];
	private final float[] v = new float[N * N];
	private int age, sinceHit, hits;
	private float radius = 0.30f;

	private WaterPond(ClientWorld world, double x, double y, double z) {
		this.world = world;
		this.cx = x;
		this.cy = y;
		this.cz = z;
	}

	/** Dipanggil saat satu tetes mendarat di (x,y,z). */
	public static void hit(ClientWorld world, double x, double y, double z, double speed) {
		for (WaterPond p : PONDS) {
			if (p.world == world && Math.abs(p.cy - y) < 0.25) {
				double dx = x - p.cx, dz = z - p.cz;
				if (dx * dx + dz * dz <= 0.64) {
					p.disturb(x, z, speed);
					return;
				}
			}
		}
		if (PONDS.size() < MAX_PONDS) {
			WaterPond p = new WaterPond(world, x, y, z);
			PONDS.add(p);
			p.disturb(x, z, speed);
		}
	}

	private void disturb(double x, double z, double speed) {
		sinceHit = 0;
		hits++;
		radius = Math.min(0.78f, 0.30f + 0.005f * hits);
		float s = (float) Math.min(0.10, 0.025 + speed * 0.05);
		int gi = (int) Math.floor((x - cx + HALF) / CELL);
		int gk = (int) Math.floor((z - cz + HALF) / CELL);
		for (int di = -2; di <= 2; di++) {
			for (int dk = -2; dk <= 2; dk++) {
				int i = gi + di, k = gk + dk;
				if (i < 0 || k < 0 || i >= N || k >= N) {
					continue;
				}
				v[i * N + k] -= s * (float) Math.exp(-(di * di + dk * dk) / 2.0);
			}
		}
	}

	private float hAt(int i, int k) {
		i = Math.max(0, Math.min(N - 1, i));
		k = Math.max(0, Math.min(N - 1, k));
		return h[i * N + k];
	}

	private void tick() {
		age++;
		sinceHit++;
		for (int i = 0; i < N; i++) {
			for (int k = 0; k < N; k++) {
				float c = h[i * N + k];
				float lap = hAt(i - 1, k) + hAt(i + 1, k) + hAt(i, k - 1) + hAt(i, k + 1) - 4 * c;
				int idx = i * N + k;
				v[idx] = (v[idx] + lap * 0.28f) * 0.993f;
			}
		}
		for (int i = 0; i < N * N; i++) {
			h[i] = Math.max(-0.08f, Math.min(0.08f, h[i] + v[i]));
		}
	}

	private boolean dead() {
		return sinceHit > 115;
	}

	private float radiusNow() {
		float r = radius * (0.4f + 0.6f * Math.min(1f, age / 15f));
		if (sinceHit > 60) {
			r *= Math.max(0f, 1f - (sinceHit - 60) / 50f);
		}
		return r;
	}

	private float mask(double x, double z, float r) {
		double dx = x - cx, dz = z - cz;
		float d = (float) Math.sqrt(dx * dx + dz * dz);
		float m = Math.max(0f, Math.min(1f, (r - d) / 0.12f));
		return m * m * (3 - 2 * m);
	}

	private void draw(VertexConsumer vc, Matrix4f mat) {
		float r = radiusNow();
		if (r <= 0.01f) {
			return;
		}
		float base = Math.min(0.07f, 0.03f + 0.0003f * hits) * Math.min(1f, age / 12f);
		int light = WorldRenderer.getLightmapCoordinates(world, BlockPos.ofFloored(cx, cy + 0.5, cz));

		float[] px = new float[N * N];
		float[] pz = new float[N * N];
		float[] py = new float[N * N];
		float[] m = new float[N * N];
		float[] spec = new float[N * N];
		float[] hv = new float[N * N];
		for (int i = 0; i < N; i++) {
			for (int k = 0; k < N; k++) {
				int idx = i * N + k;
				double x = cx - HALF + (i + 0.5) * CELL;
				double z = cz - HALF + (k + 0.5) * CELL;
				float mk = mask(x, z, r);
				px[idx] = (float) x;
				pz[idx] = (float) z;
				m[idx] = mk;
				hv[idx] = h[idx];
				py[idx] = (float) (cy + 0.015 + (base + h[idx]) * mk);
				float gx = hAt(i + 1, k) - hAt(i - 1, k);
				float gz = hAt(i, k + 1) - hAt(i, k - 1);
				spec[idx] = Math.min(1f, (Math.abs(gx) + Math.abs(gz)) * 45f);
			}
		}
		for (int i = 0; i < N - 1; i++) {
			for (int k = 0; k < N - 1; k++) {
				int a = i * N + k, b = (i + 1) * N + k, c = (i + 1) * N + k + 1, d = i * N + k + 1;
				if (m[a] <= 0 && m[b] <= 0 && m[c] <= 0 && m[d] <= 0) {
					continue;
				}
				put(vc, mat, px[a], py[a], pz[a], m[a], spec[a], hv[a], light);
				put(vc, mat, px[b], py[b], pz[b], m[b], spec[b], hv[b], light);
				put(vc, mat, px[c], py[c], pz[c], m[c], spec[c], hv[c], light);
				put(vc, mat, px[d], py[d], pz[d], m[d], spec[d], hv[d], light);
			}
		}
	}

	private static void put(VertexConsumer vc, Matrix4f mat, float x, float y, float z,
	                        float m, float spec, float hh, int light) {
		// busa putih tipis di tepi kolam + kilau di lereng gelombang
		float foam = 4f * m * (1f - m);
		float w = Math.max(0f, Math.min(1f, spec * 0.9f + foam * 0.6f));
		float shade = 1f + hh * 4f;
		float rr = Math.min(1f, (0.18f + 0.77f * w) * shade);
		float gg = Math.min(1f, (0.65f + 0.33f * w) * shade);
		float bb = Math.min(1f, (0.85f + 0.15f * w) * shade);
		float aa = (0.55f + 0.30f * w) * m;
		vc.vertex(mat, x, y, z).color(rr, gg, bb, aa).texture(0.5f, 0.5f)
			.overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0f, 1f, 0f);
	}

	/** Dipanggil tiap akhir tick client. */
	public static void tickAll() {
		ClientWorld current = MinecraftClient.getInstance().world;
		PONDS.removeIf(p -> p.world != current || p.dead());
		for (WaterPond p : PONDS) {
			p.tick();
		}
	}

	/** Dipanggil saat menggambar dunia (setelah objek transparan). */
	public static void render(WorldRenderContext ctx) {
		if (PONDS.isEmpty() || ctx.consumers() == null || ctx.matrixStack() == null) {
			return;
		}
		VertexConsumerProvider consumers = ctx.consumers();
		RenderLayer layer = RenderLayer.getEntityTranslucent(WHITE);
		VertexConsumer vc = consumers.getBuffer(layer);
		MatrixStack stack = ctx.matrixStack();
		Vec3d cam = ctx.camera().getPos();
		stack.push();
		stack.translate(-cam.x, -cam.y, -cam.z);
		Matrix4f mat = stack.peek().getPositionMatrix();
		for (WaterPond p : PONDS) {
			p.draw(vc, mat);
		}
		stack.pop();
		if (consumers instanceof VertexConsumerProvider.Immediate imm) {
			imm.draw(layer);
		}
	}
}
