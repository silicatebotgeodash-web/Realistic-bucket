package com.realisticwater;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Ember "realistis": tahan klik kanan untuk menuang air.
 * Air dituang sebagai tetesan partikel yang disimulasikan di sisi client (lihat WaterDropParticle).
 */
public class RealisticBucketItem extends Item {

	/** Jumlah tetesan per tick saat menuang. */
	private static final int DROPS_PER_TICK = 5;

	public RealisticBucketItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		user.setCurrentHand(hand);
		world.playSound(user, user.getBlockPos(), SoundEvents.ITEM_BUCKET_EMPTY, SoundCategory.PLAYERS, 0.8f, 1.0f);
		return TypedActionResult.consume(stack);
	}

	@Override
	public UseAction getUseAction(ItemStack stack) {
		return UseAction.NONE;
	}

	@Override
	public int getMaxUseTime(ItemStack stack, LivingEntity user) {
		return 72000;
	}

	@Override
	public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
		if (!world.isClient) {
			return;
		}
		Vec3d look = user.getRotationVec(1.0f);
		Vec3d eye = user.getEyePos();
		Vec3d origin = eye.add(look.multiply(0.7)).add(0, -0.25, 0);
		for (int i = 0; i < DROPS_PER_TICK; i++) {
			double vx = look.x * 0.26 + world.random.nextGaussian() * 0.025;
			double vy = look.y * 0.26 + world.random.nextGaussian() * 0.025;
			double vz = look.z * 0.26 + world.random.nextGaussian() * 0.025;
			double ox = origin.x + world.random.nextGaussian() * 0.04;
			double oy = origin.y + world.random.nextGaussian() * 0.04;
			double oz = origin.z + world.random.nextGaussian() * 0.04;
			world.addParticle(RealisticWater.WATER_DROP, ox, oy, oz, vx, vy, vz);
		}
	}
}
