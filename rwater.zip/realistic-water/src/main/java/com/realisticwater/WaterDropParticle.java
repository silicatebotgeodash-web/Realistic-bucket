package com.realisticwater;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Satu tetes air. Tiap tetes punya fisika sendiri:
 *  - gravitasi + tabrakan dengan blok
 *  - tolak-menolak dengan tetes lain di dekatnya (mirip tekanan fluida, bikin air menyebar jadi genangan)
 *  - viskositas (kecepatan disamakan dengan tetangga, bikin aliran menyatu)
 *  - percikan saat menghantam tanah dengan cepat
 *  - hilang kalau masuk ke air asli, atau menguap/mengecil setelah beberapa detik
 *
 * Tetangga dicari lewat grid spasial, jadi tetap ringan walau ratusan tetes.
 */
public class WaterDropParticle extends SpriteBillboardParticle {

	/** Batas maksimum tetes aktif (kurangi kalau lag). */
	public static final int MAX = 900;
	/** Radius interaksi antar tetes (blok). */
	private static final double H = 0.28;

	private static final ArrayList<WaterDropParticle> ALL = new ArrayList<>();
	private static final HashMap<Long, ArrayList<WaterDropParticle>> GRID = new HashMap<>();

	private final float dropScale;
	private final float flatScale;
	private final float phase;

	private WaterDropParticle(ClientWorld world, double x, double y, double z,
	                          double vx, double vy, double vz, SpriteProvider sprites) {
		super(world, x, y, z);
		this.setSprite(sprites);
		this.velocityX = vx;
		this.velocityY = vy;
		this.velocityZ = vz;
		this.maxAge = 110 + this.random.nextInt(50);
		this.dropScale = 0.035f + this.random.nextFloat() * 0.015f;
		this.flatScale = 0.15f + this.random.nextFloat() * 0.05f;
		this.phase = this.random.nextFloat() * 6.2832f;
		this.scale = this.dropScale;
		this.setBoundingBoxSpacing(0.08f, 0.08f);
		this.collidesWithWorld = true;
		this.setColor(0.80f, 0.94f, 1.0f);
		this.setAlpha(0.6f);
		ALL.add(this);
	}

	@Override
	public ParticleTextureSheet getType() {
		return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
	}

	@Override
	public void tick() {
		this.prevPosX = this.x;
		this.prevPosY = this.y;
		this.prevPosZ = this.z;

		if (this.age++ >= this.maxAge) {
			this.markDead();
			return;
		}
		int left = this.maxAge - this.age;

		// masuk ke air asli -> menyatu
		BlockPos bp = BlockPos.ofFloored(this.x, this.y, this.z);
		if (this.world.getFluidState(bp).isIn(FluidTags.WATER)) {
			if (this.velocityY < -0.15) {
				this.world.addParticle(ParticleTypes.SPLASH, this.x, this.y, this.z, 0, 0.1, 0);
			}
			this.markDead();
			return;
		}

		interact();

		this.velocityY -= 0.045;
		double fallSpeed = this.velocityY;
		this.move(this.velocityX, this.velocityY, this.velocityZ);

		if (this.onGround) {
			// benturan keras -> percikan
			if (fallSpeed < -0.40 && this.random.nextInt(3) == 0) {
				this.world.addParticle(ParticleTypes.SPLASH, this.x, this.y + 0.05, this.z, 0, 0.1, 0);
				int n = 1 + this.random.nextInt(2);
				for (int i = 0; i < n; i++) {
					this.world.addParticle(RealisticWater.WATER_DROP, this.x, this.y + 0.05, this.z,
						(this.random.nextDouble() - 0.5) * 0.14,
						0.16 + this.random.nextDouble() * 0.10,
						(this.random.nextDouble() - 0.5) * 0.14);
				}
			}
			this.velocityX *= 0.55;
			this.velocityZ *= 0.55;
			this.velocityY = 0;
		} else {
			this.velocityX *= 0.99;
			this.velocityY *= 0.99;
			this.velocityZ *= 0.99;
		}

		// tampilan: jatuh = tetes kecil bening; mendarat = bidang air tipis yang berkilau
		float fade = left < 40 ? left / 40.0f : 1.0f;
		if (this.onGround) {
			float sh = 0.5f + 0.5f * (float) Math.sin(this.age * 0.25 + this.phase);
			sh = sh * sh;
			this.scale = this.flatScale;
			this.red = 0.22f + 0.65f * sh;
			this.green = 0.68f + 0.30f * sh;
			this.blue = 0.82f + 0.15f * sh;
			this.alpha = (0.30f + 0.15f * sh) * fade;
		} else {
			this.scale = this.dropScale;
			this.red = 0.80f;
			this.green = 0.94f;
			this.blue = 1.0f;
			this.alpha = 0.6f * fade;
		}
	}

	/** Tetes yang sudah mendarat digambar datar di tanah (seperti permukaan air); yang jatuh tetap billboard. */
	@Override
	public void buildGeometry(VertexConsumer vc, Camera camera, float tickDelta) {
		if (!this.onGround) {
			super.buildGeometry(vc, camera, tickDelta);
			return;
		}
		Vec3d cam = camera.getPos();
		float px = (float) (MathHelper.lerp(tickDelta, this.prevPosX, this.x) - cam.x);
		float py = (float) (MathHelper.lerp(tickDelta, this.prevPosY, this.y) - cam.y) + 0.02f;
		float pz = (float) (MathHelper.lerp(tickDelta, this.prevPosZ, this.z) - cam.z);
		float s = this.scale;
		float u0 = this.getMinU(), u1 = this.getMaxU(), v0 = this.getMinV(), v1 = this.getMaxV();
		int light = this.getBrightness(tickDelta);
		vc.vertex(px - s, py, pz - s).texture(u1, v1).color(this.red, this.green, this.blue, this.alpha).light(light);
		vc.vertex(px - s, py, pz + s).texture(u1, v0).color(this.red, this.green, this.blue, this.alpha).light(light);
		vc.vertex(px + s, py, pz + s).texture(u0, v0).color(this.red, this.green, this.blue, this.alpha).light(light);
		vc.vertex(px + s, py, pz - s).texture(u0, v1).color(this.red, this.green, this.blue, this.alpha).light(light);
	}

	/** Gaya antar tetes: tolak (tekanan) + samakan kecepatan (viskositas). */
	private void interact() {
		int cx = cell(this.x), cy = cell(this.y), cz = cell(this.z);
		double px = 0, py = 0, pz = 0;
		double avx = 0, avy = 0, avz = 0;
		int n = 0;
		double h2 = H * H;

		for (int dx = -1; dx <= 1; dx++) {
			for (int dy = -1; dy <= 1; dy++) {
				for (int dz = -1; dz <= 1; dz++) {
					ArrayList<WaterDropParticle> list = GRID.get(key(cx + dx, cy + dy, cz + dz));
					if (list == null) {
						continue;
					}
					for (WaterDropParticle o : list) {
						if (o == this) {
							continue;
						}
						double ddx = this.x - o.x, ddy = this.y - o.y, ddz = this.z - o.z;
						double d2 = ddx * ddx + ddy * ddy + ddz * ddz;
						if (d2 >= h2) {
							continue;
						}
						n++;
						if (d2 < 1.0e-6) {
							px += (this.random.nextDouble() - 0.5) * 0.05;
							pz += (this.random.nextDouble() - 0.5) * 0.05;
							continue;
						}
						double d = Math.sqrt(d2);
						double w = (H - d) / H;
						px += ddx / d * w;
						py += ddy / d * w;
						pz += ddz / d * w;
						avx += o.velocityX;
						avy += o.velocityY;
						avz += o.velocityZ;
					}
				}
			}
		}
		if (n > 0) {
			this.velocityX += px * 0.05;
			this.velocityY += py * 0.03;
			this.velocityZ += pz * 0.05;
			this.velocityX += (avx / n - this.velocityX) * 0.06;
			this.velocityY += (avy / n - this.velocityY) * 0.06;
			this.velocityZ += (avz / n - this.velocityZ) * 0.06;
			// terlalu padat -> goyang sedikit supaya tumpukan menyebar
			if (n > 5) {
				this.velocityX += (this.random.nextDouble() - 0.5) * 0.02;
				this.velocityZ += (this.random.nextDouble() - 0.5) * 0.02;
			}
		}
	}

	private static int cell(double v) {
		return (int) Math.floor(v / H);
	}

	private static long key(int x, int y, int z) {
		return ((long) (x & 0x1FFFFF) << 42) | ((long) (y & 0x1FFFFF) << 21) | (long) (z & 0x1FFFFF);
	}

	/** Dipanggil tiap akhir tick client: bersihkan yang mati dan bangun ulang grid tetangga. */
	public static void rebuild() {
		GRID.clear();
		ClientWorld current = MinecraftClient.getInstance().world;
		ALL.removeIf(p -> !p.isAlive() || p.world != current);
		for (WaterDropParticle p : ALL) {
			GRID.computeIfAbsent(key(cell(p.x), cell(p.y), cell(p.z)), k -> new ArrayList<>()).add(p);
		}
	}

	public static class Factory implements ParticleFactory<SimpleParticleType> {
		private final SpriteProvider sprites;

		public Factory(SpriteProvider sprites) {
			this.sprites = sprites;
		}

		@Override
		public Particle createParticle(SimpleParticleType type, ClientWorld world,
		                               double x, double y, double z,
		                               double vx, double vy, double vz) {
			if (ALL.size() >= MAX) {
				return null;
			}
			return new WaterDropParticle(world, x, y, z, vx, vy, vz, this.sprites);
		}
	}
}
