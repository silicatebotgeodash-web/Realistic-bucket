package com.realisticwater;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Satu tetes air. Tiap tetes punya fisika sendiri:
 *  - gravitasi + tabrakan dengan blok
 *  - tolak-menolak dengan tetes lain di dekatnya (mirip tekanan fluida, bikin air menyebar jadi genangan)
 *  - viskositas (kecepatan disamakan dengan tetangga, bikin aliran menyatu)
 *  - percikan saat menghantam tanah dengan cepat
 *  - hilang kalau masuk ke air asli, atau menguap/mengecil setelah beberapa detik
 *
 * Tetangga dicari lewat grid spasial, jadi tetap ringan walau ratusan tetes.
 */
public class WaterDropParticle extends SpriteBillboardParticle {

	/** Batas maksimum tetes aktif (kurangi kalau lag). */
	public static final int MAX = 900;
	/** Radius interaksi antar tetes (blok). */
	private static final double H = 0.28;

	private static final ArrayList<WaterDropParticle> ALL = new ArrayList<>();
	private static final HashMap<Long, ArrayList<WaterDropParticle>> GRID = new HashMap<>();

	private final float baseScale;

	private WaterDropParticle(ClientWorld world, double x, double y, double z,
	                          double vx, double vy, double vz, SpriteProvider sprites) {
		super(world, x, y, z);
		this.setSprite(sprites);
		this.velocityX = vx;
		this.velocityY = vy;
		this.velocityZ = vz;
		this.maxAge = 240 + this.random.nextInt(120);
		this.baseScale = 0.10f + this.random.nextFloat() * 0.03f;
		this.scale = this.baseScale;
		this.setBoundingBoxSpacing(0.08f, 0.08f);
		this.collidesWithWorld = true;
		this.setColor(0.30f, 0.58f, 1.0f);
		this.setAlpha(0.85f);
		ALL.add(this);
	}

	@Override
	public ParticleTextureSheet getType() {
		return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
	}

	@Override
	public void tick() {
		this.prevPosX = this.x;
		this.prevPosY = this.y;
		this.prevPosZ = this.z;

		if (this.age++ >= this.maxAge) {
			this.markDead();
			return;
		}
		int left = this.maxAge - this.age;
		if (left < 20) {
			this.scale = this.baseScale * (left / 20.0f);
		}

		// masuk ke air asli -> menyatu
		BlockPos bp = BlockPos.ofFloored(this.x, this.y, this.z);
		if (this.world.getFluidState(bp).isIn(FluidTags.WATER)) {
			if (this.velocityY < -0.15) {
				this.world.addParticle(ParticleTypes.SPLASH, this.x, this.y, this.z, 0, 0.1, 0);
			}
			this.markDead();
			return;
		}

		interact();

		this.velocityY -= 0.045;
		double fallSpeed = this.velocityY;
		this.move(this.velocityX, this.velocityY, this.velocityZ);

		if (this.onGround) {
			// benturan keras -> percikan
			if (fallSpeed < -0.40 && this.random.nextInt(3) == 0) {
				this.world.addParticle(ParticleTypes.SPLASH, this.x, this.y + 0.05, this.z, 0, 0.1, 0);
				int n = 1 + this.random.nextInt(2);
				for (int i = 0; i < n; i++) {
					this.world.addParticle(RealisticWater.WATER_DROP, this.x, this.y + 0.05, this.z,
						(this.random.nextDouble() - 0.5) * 0.14,
						0.16 + this.random.nextDouble() * 0.10,
						(this.random.nextDouble() - 0.5) * 0.14);
				}
			}
			this.velocityX *= 0.55;
			this.velocityZ *= 0.55;
			this.velocityY = 0;
		} else {
			this.velocityX *= 0.99;
			this.velocityY *= 0.99;
			this.velocityZ *= 0.99;
		}
	}

	/** Gaya antar tetes: tolak (tekanan) + samakan kecepatan (viskositas). */
	private void interact() {
		int cx = cell(this.x), cy = cell(this.y), cz = cell(this.z);
		double px = 0, py = 0, pz = 0;
		double avx = 0, avy = 0, avz = 0;
		int n = 0;
		double h2 = H * H;

		for (int dx = -1; dx <= 1; dx++) {
			for (int dy = -1; dy <= 1; dy++) {
				for (int dz = -1; dz <= 1; dz++) {
					ArrayList<WaterDropParticle> list = GRID.get(key(cx + dx, cy + dy, cz + dz));
					if (list == null) {
						continue;
					}
					for (WaterDropParticle o : list) {
						if (o == this) {
							continue;
						}
						double ddx = this.x - o.x, ddy = this.y - o.y, ddz = this.z - o.z;
						double d2 = ddx * ddx + ddy * ddy + ddz * ddz;
						if (d2 >= h2) {
							continue;
						}
						n++;
						if (d2 < 1.0e-6) {
							px += (this.random.nextDouble() - 0.5) * 0.05;
							pz += (this.random.nextDouble() - 0.5) * 0.05;
							continue;
						}
						double d = Math.sqrt(d2);
						double w = (H - d) / H;
						px += ddx / d * w;
						py += ddy / d * w;
						pz += ddz / d * w;
						avx += o.velocityX;
						avy += o.velocityY;
						avz += o.velocityZ;
					}
				}
			}
		}
		if (n > 0) {
			this.velocityX += px * 0.05;
			this.velocityY += py * 0.03;
			this.velocityZ += pz * 0.05;
			this.velocityX += (avx / n - this.velocityX) * 0.06;
			this.velocityY += (avy / n - this.velocityY) * 0.06;
			this.velocityZ += (avz / n - this.velocityZ) * 0.06;
			// terlalu padat -> goyang sedikit supaya tumpukan menyebar
			if (n > 5) {
				this.velocityX += (this.random.nextDouble() - 0.5) * 0.02;
				this.velocityZ += (this.random.nextDouble() - 0.5) * 0.02;
			}
		}
	}

	private static int cell(double v) {
		return (int) Math.floor(v / H);
	}

	private static long key(int x, int y, int z) {
		return ((long) (x & 0x1FFFFF) << 42) | ((long) (y & 0x1FFFFF) << 21) | (long) (z & 0x1FFFFF);
	}

	/** Dipanggil tiap akhir tick client: bersihkan yang mati dan bangun ulang grid tetangga. */
	public static void rebuild() {
		GRID.clear();
		ClientWorld current = MinecraftClient.getInstance().world;
		ALL.removeIf(p -> !p.isAlive() || p.world != current);
		for (WaterDropParticle p : ALL) {
			GRID.computeIfAbsent(key(cell(p.x), cell(p.y), cell(p.z)), k -> new ArrayList<>()).add(p);
		}
	}

	public static class Factory implements ParticleFactory<SimpleParticleType> {
		private final SpriteProvider sprites;

		public Factory(SpriteProvider sprites) {
			this.sprites = sprites;
		}

		@Override
		public Particle createParticle(SimpleParticleType type, ClientWorld world,
		                               double x, double y, double z,
		                               double vx, double vy, double vz) {
			if (ALL.size() >= MAX) {
				return null;
			}
			return new WaterDropParticle(world, x, y, z, vx, vy, vz, this.sprites);
		}
	}
}
