package com.realisticwater;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class RealisticWater implements ModInitializer {
	public static final String MOD_ID = "realisticwater";

	public static final SimpleParticleType WATER_DROP = FabricParticleTypes.simple(true);

	public static final Item REALISTIC_BUCKET = new RealisticBucketItem(new Item.Settings().maxCount(1));

	@Override
	public void onInitialize() {
		Registry.register(Registries.PARTICLE_TYPE, Identifier.of(MOD_ID, "water_drop"), WATER_DROP);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "realistic_bucket"), REALISTIC_BUCKET);

		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> entries.add(REALISTIC_BUCKET));
	}
}
