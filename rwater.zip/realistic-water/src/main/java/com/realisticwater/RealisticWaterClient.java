package com.realisticwater;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

public class RealisticWaterClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ParticleFactoryRegistry.getInstance().register(RealisticWater.WATER_DROP, WaterDropParticle.Factory::new);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			WaterDropParticle.rebuild();
			WaterPond.tickAll();
		});
		WorldRenderEvents.AFTER_TRANSLUCENT.register(WaterPond::render);
	}
}
