# Realistic Water (Fabric 1.21.1)

Item **Realistic Bucket** (tampilan sama seperti ember air). Tahan klik kanan untuk menuang air
berupa ratusan tetesan dengan fisika: jatuh, memantul, memercik, saling dorong dan menggenang.
Air bawaan Minecraft tidak diubah.

Dapatkan: `/give @s realisticwater:realistic_bucket` atau craft ember air + lapis (tanpa bentuk).
Butuh Fabric API 0.116.x untuk 1.21.1.
